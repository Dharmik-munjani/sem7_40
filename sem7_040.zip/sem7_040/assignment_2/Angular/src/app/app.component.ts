import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  emp=[
    {
    id:1,
    name:'abc'
  },
  {
    id:2,
    name:'xyz'
  },
];
  title = 'angappexam';


  
}
